from setuptools import setup

setup(
    name='velox',
    version='3.0.0.266',
    packages=['velox'],
    url='',
    license='See Formfactor Velox Product License.',
    author='Formfactor',
    author_email='',
    description='Python 2.7+ and 3.5+ interface for Velox',
    include_package_data=True
)
