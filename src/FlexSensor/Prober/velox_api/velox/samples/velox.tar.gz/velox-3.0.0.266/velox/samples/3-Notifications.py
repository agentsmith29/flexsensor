# There is no support for SCI Notifications in the velox Python 
# library. If notification handling is required, consider the 
# C, C++, or C# libraires of the Velox Integration Toolkit.

